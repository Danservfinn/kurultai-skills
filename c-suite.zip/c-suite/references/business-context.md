# Kurultai LLC - Complete Business Context

## Entity Details

| Field | Value |
|-------|-------|
| **Legal Name** | Kurultai Limited Liability Company |
| **DBA** | Parse (when needed) |
| **State** | North Carolina |
| **File Number** | 2438266 |
| **Formation Date** | January 18, 2026 |
| **Registered Agent** | Daniel S Finn |
| **Principal Address** | 319 W Lenoir St Apt 1401, Raleigh, NC 27601 |
| **Registered Agent Address** | Ste B 211, 1109 Cross Link Rd, Raleigh, NC 27610 |
| **Tax Status** | Sole proprietorship (default until S-Corp election) |

## Products & Ventures

### Parse (Primary - Active)
- **Type**: AI-powered media analysis platform
- **Status**: Active, in production
- **Technology Stack**: Next.js, TypeScript, PostgreSQL, Anthropic Claude API
- **Business Model**: B2B SaaS, AI-powered content analysis
- **Key Features**: Steel-manning, manipulation detection, truth quantification

### Future Products
- In development planning phase
- Will be evaluated based on Parse performance and market opportunities

## Banking & Finance

### Banking Provider
- **Recommended**: Mercury (mercury.com)
- **Rationale**: API access, programmatic ACH, webhook support, $0 monthly fee
- **Status**: Account pending (awaiting EIN)

### Financial Structure
- **Holding Company Model**: Kurultai LLC owns all products/ventures
- **Expense Categories**:
  - Software & Infrastructure (hosting, APIs, tools)
  - Development & Operations (Parse development costs)
  - Professional Services (legal, accounting, consulting)
  - Marketing & Growth (customer acquisition)
  - Administrative (banking, compliance, office)

## Compliance Calendar

| Date | Requirement | Cost | Status |
|------|-------------|------|--------|
| January 1, 2027 | NC Annual Report | $138.75 | ⬜ Upcoming |
| April 15, 2026 | Federal Tax Return (Sole Prop) | Varies | ⬜ Upcoming |
| April 15, 2026 | NC State Tax Return | Varies | ⬜ Upcoming |
| Within 75 days of formation | S-Corp Election (Form 2553) | Free | Optional |

## Tax Elections

### Current Status
- **Default**: Sole proprietorship (pass-through taxation)
- **Self-Employment Tax**: Full amount on all LLC income

### Future Consideration: S-Corp Election
- **Trigger**: When annual profit exceeds $60,000
- **Benefit**: Save on self-employment tax (15.3%)
- **Cost**: ~$2,000/year in payroll processing
- **Deadline**: Within 75 days of formation (by April 3, 2026) OR for next tax year
- **Form**: IRS Form 2553

## Decision History

### 2026-01-18: New LLC Formation vs Reinstatement
**Decision**: Formed new LLC instead of reinstating dissolved entity
**Rationale**:
- Cost: $125 vs ~$700+ for reinstatement
- Simplicity: One form vs multiple back filings
- Clean slate: New EIN, no baggage
- Old dissolved entity stays in past

### 2026-01-18: Business Banking Selection
**Decision**: Selected Mercury as business banking provider
**Rationale**:
- Read-write API for Claude Code automation
- Webhook support for real-time transaction monitoring
- 100 free ACH transfers/month
- $0 monthly fee, no minimum balance
- Best developer experience

## Vendor Relationships

### Active Vendors
- **Vercel**: Parse hosting and deployment
- **Anthropic**: Claude API for Parse AI features
- **PostgreSQL**: Database hosting (provider TBD)
- **North Carolina Secretary of State**: LLC formation and compliance

### Future Vendor Needs
- **Accounting/Bookkeeping**: QuickBooks, Xero, or Wave
- **Payroll** (if S-Corp): Gusto, Remote, or similar
- **Legal**: Business attorney for contract review
- **Insurance**: General liability, E&O insurance

## File Structure Reference

```
~/kurultai/kurultaillc/
├── STRUCTURE.md              # Master index (always check first)
├── docs/
│   ├── README.md             # Business overview
│   ├── QUICK_START.md        # Formation quick start
│   ├── LLC_SETUP_CHECKLIST.md # Detailed checklist
│   ├── formation/            # Formation documents ONLY
│   │   └── 2026-01-18-articles-of-organization-certificate.pdf
│   ├── government/           # All government correspondence
│   │   ├── (future: EIN confirmation)
│   │   ├── (future: Annual report filings)
│   │   └── (future: S-Corp election)
│   ├── tax/                  # Tax documents
│   │   ├── (future: 2026 tax return)
│   │   └── (future: Quarterly estimates)
│   ├── legal/                # Legal agreements
│   │   ├── OPERATING_AGREEMENT_TEMPLATE.md
│   │   └── (future: Contracts, NDAs)
│   └── financial/            # Banking & financial records
│       ├── (future: Bank statements)
│       ├── (future: Merchant statements)
│       └── (future: Insurance policies)
└── templates/                # Reusable templates
```

## Key Contacts

| Role | Name | Contact |
|------|------|---------|
| Owner | Daniel S Finn | 319 W Lenoir St Apt 1401, Raleigh, NC 27601 |
| Registered Agent | Daniel S Finn | Ste B 211, 1109 Cross Link Rd, Raleigh, NC 27610 |

## Operational Guidelines

1. **Record Keeping**: Every document, transaction, and decision must be documented
2. **Separation**: Maintain clear separation between holding company and product operations
3. **Compliance First**: Never miss deadlines; stay ahead of requirements
4. **Data Driven**: Use metrics for all significant decisions
5. **Persistent Memory**: Log everything to Notion for continuity

---

*Last Updated: 2026-01-18*
