---
name: critical-review
description: This skill performs comprehensive multi-disciplinary critical reviews of designs, plans, and technical artifacts by analyzing from multiple expert perspectives: UX, backend, frontend, architecture, data science, data engineering, fullstack, prompt engineering, and DevOps. Use this skill when the user asks to "critically review," "critique," "evaluate," or perform "adversarial analysis" of web pages, features, systems, architectures, or any design/document. The skill synthesizes findings into a consolidated report and presents suggested improvements for batch approval.
---

# Critical Review

Perform comprehensive multi-disciplinary reviews by analyzing artifacts from multiple expert perspectives. This skill conducts the review directly—simulating the expertise of specialists across UX, backend, frontend, architecture, data, and DevOps—then synthesizes findings into a consolidated report with actionable improvements.

## When to Use This Skill

Invoke this skill when:
- The user explicitly requests a "critical review," "critique," "evaluation," or "adversarial analysis" of any artifact
- A design document, API specification, system architecture, or feature plan requires comprehensive expert validation
- There's a need to identify weaknesses, risks, and improvement opportunities across multiple technical domains
- The user wants adversarial or skeptical analysis to stress-test proposals before implementation

**Note:** For focused adversarial analysis of web pages with data/ML claims, use the `critical-reviewer` skill instead.

## Review Workflow

### Phase 1: Context Gathering

Before conducting the review, establish context:

1. **Identify the artifact under review** - This may be:
   - A web page or URL (use browser automation tools to capture if needed)
   - A design document or specification file (read the file)
   - Code repository or architecture diagram
   - Feature plan or PRD
   - Database schema or API contract

2. **Gather existing context** - Leverage available context sources:
   - **Current conversation** - Review any prior discussion about the artifact
   - **Claude memory** - Use the 3-layer MCP search workflow:
     1. `mcp__plugin_claude-mem_mcp-search__search` - Search for project/feature keywords to get observation IDs
     2. `mcp__plugin_claude-mem_mcp-search__timeline` - Get context around interesting observations
     3. `mcp__plugin_claude-mem_mcp-search__get_observations` - Fetch full details only for filtered IDs
   - **Project documentation** - ARCHITECTURE.md, design docs, prior reviews

3. **Establish review scope** - Determine which domains are relevant:
   - **All domains** for full system reviews, major features, or end-to-end architectures
   - **Subset of domains** for focused reviews (e.g., only backend + DevOps for API changes)

### Phase 2: Conduct Multi-Domain Analysis

Analyze the artifact from each relevant domain perspective. For each domain, apply the appropriate lens and identify issues:

**Domain-specific analysis lenses:**

| Domain | Focus Areas | Key Questions |
|--------|-------------|---------------|
| **UX & Accessibility** | Usability, accessibility (WCAG), interaction design, user journeys | Are interfaces intuitive? Is it keyboard accessible? Are labels proper? Is error messaging clear? |
| **Backend** | API design, data modeling, performance, scalability, security, error handling | Are endpoints RESTful? Is data properly validated? How are authentication/authorization handled? |
| **Frontend** | Component architecture, state management, performance, responsiveness, accessibility | Are components reusable? Is state managed efficiently? Is it responsive? Are loading states handled? |
| **Architecture** | System design, scalability, maintainability, SOLID principles, integration patterns | Are boundaries clear? Is it loosely coupled? Can it scale? Is technical debt manageable? |
| **Data Science** | Statistical validity, ML/AI appropriateness, data interpretation, experimental design | Are metrics valid? Is ML appropriate? Is there bias? Are conclusions justified? |
| **Data Engineering** | Data pipelines, schema design, ETL/ELT, data quality, observability | Are pipelines reliable? Is schema normalized? Is data quality monitored? |
| **Fullstack** | End-to-end coherence, integration, testing coverage, developer experience | Do frontend/backend align? Is error handling consistent? Is it testable? |
| **Prompt Engineering** | LLM integration, prompt design, RAG effectiveness, output validation | Are prompts well-designed? Is RAG effective? Is output validated? Are prompt injection risks mitigated? |
| **DevOps** | Infrastructure, CI/CD, monitoring, logging, deployment, reliability | Is infrastructure scalable? Is deployment automated? Are metrics monitored? Is logging adequate? |

**Conduct the analysis by:**
1. Reading/examining the artifact thoroughly
2. Applying each relevant domain's lens systematically
3. Documenting findings with specific references
4. Identifying severity and impact for each finding

### Phase 3: Synthesis and Consolidation

After completing the domain analyses, synthesize the findings:

1. **Categorize findings** by domain:
   - User Experience & Accessibility
   - Backend & API Design
   - Frontend & Implementation
   - Architecture & System Design
   - Data & Analytics
   - Infrastructure & DevOps
   - Security & Performance
   - AI/LLM Integration (if applicable)

2. **Prioritize by severity/impact:**
   - **Critical** - Security vulnerabilities, data loss risks, legal compliance issues
   - **High** - Major usability problems, performance bottlenecks, scalability risks
   - **Medium** - Code quality issues, maintainability concerns, minor UX friction
   - **Low** - Nice-to-have improvements, optimizations, style suggestions

3. **Identify cross-cutting themes** - Issues that multiple domains flagged (e.g., "scalability concerns raised by backend, architect, and DevOps")

### Phase 4: Report Presentation

Present the consolidated critical review report using the complete structure below. Fill in each section with actual findings; omit sections with no findings.

```markdown
# Critical Review Report: [Artifact Name]

## Executive Summary
[Brief overview of what was reviewed and overall assessment - 2-3 sentences]

## Findings by Domain

### User Experience & Accessibility
- [Specific finding with reference]
- [Specific finding with reference]

### Backend & API Design
- [Specific finding with reference]
- [Specific finding with reference]

### Frontend & Implementation
- [Specific finding with reference]
- [Specific finding with reference]

### Architecture & System Design
- [Specific finding with reference]
- [Specific finding with reference]

### Data & Analytics
- [Specific finding with reference]
- [Specific finding with reference]

### Infrastructure & DevOps
- [Specific finding with reference]
- [Specific finding with reference]

### Security & Performance
- [Specific finding with reference]
- [Specific finding with reference]

### AI/LLM Integration
- [Specific finding with reference]
- [Specific finding with reference]

## Cross-Cutting Concerns
[Issues flagged by multiple domains, with note of which domains raised each]

## Prioritized Improvement List

| Priority | Domain | Issue | Suggested Action |
|----------|--------|-------|------------------|
| Critical | Security | [Description] | [Action] |
| High | Performance | [Description] | [Action] |
| Medium | [Domain] | [Description] | [Action] |
| Low | [Domain] | [Description] | [Action] |
```

### Phase 5: Batch Approval Workflow

After presenting the report, facilitate batch approval:

1. **Present the approval question:**
   ```
   Which improvements would you like to approve for implementation?

   You can:
   - Specify individual items by number (e.g., "1, 3, 5")
   - Approve by priority tier (e.g., "all Critical and High")
   - Approve all items (e.g., "all")
   - Reject or defer items (e.g., "skip 4, defer 7")
   ```

2. **Record approved items** - Create a structured list

3. **Offer next steps** using AskUserQuestion:
   - Implement approved items immediately
   - Create implementation tasks/tickets
   - Delegate to appropriate specialized agents:
     - `backend-development:backend-architect` for backend/architecture issues
     - `frontend-mobile-development:frontend-developer` for frontend issues
     - `python-development:python-pro` for Python-specific work
     - `senior-devops` for infrastructure/DevOps issues

## Review Quality Standards

Ensure all reviews meet these standards:

- **Specific** - Point to exact files, lines, or components, not vague concerns
- **Actionable** - Each issue includes a concrete improvement suggestion
- **Evidence-based** - Ground critiques in analysis, not opinion
- **Constructive** - Frame issues as improvement opportunities
- **Context-aware** - Consider constraints, timelines, and trade-offs

## Adversarial Analysis Mode

When explicit adversarial analysis is requested:

- Challenge assumptions in the design
- Look for failure modes and edge cases
- Question whether the solution actually solves the stated problem
- Identify where the design could break under stress
- Flag where human error could cause problems
- Consider malicious or misuse scenarios

## Exit Conditions

Complete the review when:
- All relevant domains have been analyzed
- Findings are synthesized into a consolidated report
- The user has reviewed and approved/rejected improvement suggestions
- Next steps are clear
